package org.eclipse.jem.tests.beaninfo;
/*******************************************************************************
 * Copyright (c) 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

/**
 * Purpose of this test is to make sure that a property
 * that is an inner class will be introspected correctly,
 * and if we then introspect that inner class, it should be
 * proper too.
 */
public class Customer {
   public class Account {
        private int balance;
        private int acctNumber;

        public int getBalance() {return balance;}
        public void setBalance(int b) { balance = b; }
        public int getAcctNumber() { return acctNumber; }
        public void setAcctNumber(int a) { acctNumber = a; }
   }

   private String name;
   private Account savings;
   
   public String getName() { return name; }
   public void setName(String n) { name = n; }
   public Account getSavings() { return savings; }
   public void setSavings(Account a) { savings = a; }
}