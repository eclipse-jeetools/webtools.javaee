package org.eclipse.jem.tests.beaninfo;
/*******************************************************************************
 * Copyright (c) 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

import java.util.EventListener;
import java.util.EventObject;
/**
 * Interface for listener for testing events. Test1Class event.
 */
public interface ITest1ClassEventListener extends EventListener {

	public void event1(EventObject event);
	public void notevent1();
	public void event2(EventObject event);
}
