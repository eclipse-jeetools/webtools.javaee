package org.eclipse.jem.tests.beaninfo;
/*******************************************************************************
 * Copyright (c) 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/


import java.beans.*;

import org.eclipse.jem.tests.beaninfo.preq.infos.BaseBeanInfo;
public class Test2ClassBeanInfo extends BaseBeanInfo {

	/* (non-Javadoc)
	 * @see java.beans.BeanInfo#getAdditionalBeanInfo()
	 */
	public BeanInfo[] getAdditionalBeanInfo() {
		return null; // Don't want any super class features.
	}
	/**
	 * Gets the bean class.
	 * @return java.lang.Class
	 */
	public Class getBeanClass() {
		return Test2Class.class;
	}
	public BeanDescriptor getBeanDescriptor() {
		java.beans.BeanDescriptor aDescriptor = null;
		try {
			/* Create and return the WindowBeanInfobean descriptor. */
			aDescriptor = new java.beans.BeanDescriptor(getBeanClass());
		} catch (Throwable exception) {
		};
		return aDescriptor;
	}
	/**
	 * Return the event set descriptors for this bean.
	 * @return java.beans.EventSetDescriptor[]
	 */
	public java.beans.EventSetDescriptor[] getEventSetDescriptors() {
		try {
			EventSetDescriptor aDescriptorList[] = {
			};
			return aDescriptorList;
		} catch (Throwable exception) {
			handleException(exception);
		};
		return null;
	}
	/**
	 * @return an icon of the specified kind for JButton
	 */
	public java.awt.Image getIcon(int kind) {
		return super.getIcon(kind);
	}
	/**
	 * Return the method descriptors for this bean.
	 * @return java.beans.MethodDescriptor[]
	 */
	public java.beans.MethodDescriptor[] getMethodDescriptors() {
		try {
			MethodDescriptor aDescriptorList[] = { super.createMethodDescriptor(getBeanClass(), "isASet", //$NON-NLS-1$
				new Object[] { DISPLAYNAME, "is aSet", //$NON-NLS-1$
					EXPERT, Boolean.TRUE,
					// SHORTDESCRIPTION, "Create the window peer",
				}, new ParameterDescriptor[] {
				}, new Class[] {
				}), super.createMethodDescriptor(getBeanClass(), "setASet", //$NON-NLS-1$
				new Object[] { DISPLAYNAME, "set aSet", //$NON-NLS-1$
					EXPERT, Boolean.TRUE,
					// SHORTDESCRIPTION, "Create the window peer",
				}, new ParameterDescriptor[] {
				}, new Class[] { Boolean.TYPE })
				};
			return aDescriptorList;
		} catch (Throwable exception) {
			handleException(exception);
		};
		return null;
	}
	/**
	 * Return the property descriptors for this bean.
	 * @return java.beans.PropertyDescriptor[]
	 */
	public java.beans.PropertyDescriptor[] getPropertyDescriptors() {
		try {
			PropertyDescriptor aDescriptorList[] = {
				// focusOwner
				super.createPropertyDescriptor(getBeanClass(), "aSet", new Object[] { //$NON-NLS-1$
					EXPERT, Boolean.TRUE }), super.createIndexedPropertyDescriptor(getBeanClass(), "fooBar", new Object[] { //$NON-NLS-1$
					EXPERT, Boolean.TRUE })
					};
			return aDescriptorList;
		} catch (Throwable exception) {
			handleException(exception);
		};
		return null;
	}

}