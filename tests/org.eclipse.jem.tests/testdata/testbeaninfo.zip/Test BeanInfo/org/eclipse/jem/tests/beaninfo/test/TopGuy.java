/*
 * Created on Nov 11, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.eclipse.jem.tests.beaninfo.test;

/**
 * @author Rich Kulp
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface TopGuy extends TopGuy2 {

	public Object getObject();
	
	public void setObject(Object object);
}
