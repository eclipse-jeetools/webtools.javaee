/*
 * Created on Nov 11, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.eclipse.jem.tests.beaninfo.test;

import org.eclipse.jem.tests.beaninfo.ITest1ClassEventListener;

/**
 * @author Rich Kulp
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public interface TopGuy2 {

	public Integer getInteger();
	
	public void setInteger(Integer integer);
	
	public void addTest1ClassEventListener(ITest1ClassEventListener listener);
	public void removeTest1ClassEventListener(ITest1ClassEventListener listener);
}
