package org.eclipse.jem.tests.beaninfo;
/*******************************************************************************
 * Copyright (c) 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

/**
 * A class with some properties. Introspect's through beaninfo. No superclass properties/methods
 * show up.
 */
public class Test2Class {
	public boolean isASet() {
		return true;
	}
	public void setASet(boolean setting) {
	}

	public void setFooBar(int index, java.lang.String value) {
	}

	public String getFooBar(int index) {
		return null;
	}

	public void setFooBar(java.lang.String[] values) {
	}

	public String[] getFooBar() {
		return null;
	}
}