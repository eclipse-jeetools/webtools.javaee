package org.eclipse.jem.tests.beaninfo;
/*******************************************************************************
 * Copyright (c) 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

/**
 * A class with some properties. Introspect's through beaninfo, with super class through beaninfo.
 * Beaninfo includes superclass, so all should show up.
 */
public class Test2ClassB extends Test2Class {

	public boolean isSetA() {
		return true;
	}
	public void setSetA(boolean setting) {
	}
	
	public void setFoo(int index, String value) {
	}
	
	public String getFoo(int index) {
		return null;
	}
	
	public void setFoo(String[] values) {
	}
	
	public String[] getFoo() {
		return null;
	}
	
	public void addTest2ClassBEventListener(ITest1ClassEventListener listener) {
	}
	public void removeTest2ClassBEventListener(ITest1ClassEventListener listener) {
	}	

}