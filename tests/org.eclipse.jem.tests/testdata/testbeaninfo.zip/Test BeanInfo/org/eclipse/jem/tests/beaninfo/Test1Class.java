package org.eclipse.jem.tests.beaninfo;
/*******************************************************************************
 * Copyright (c) 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/

import java.util.TooManyListenersException;

/**
 * A class with some properties. Introspect's through reflection. All of superclass will show up.
 * (Note: Event is never actually sent. It is only for testing reflection).
 */
public class Test1Class {
	private boolean setting;
	public boolean isSet() {
		return setting;
	}
	public void setSet(boolean setting) {
		this.setting = setting;
	}

	public String toString() {
		return "Test1Class with setting of " + String.valueOf(setting);
	}

	public void setFoo(int index, java.lang.String value) {
	}

	public String getFoo(int index) {
		return null;
	}

	public void setFoo(java.lang.String[] values) {
	}

	public String[] getFoo() {
		return null;
	}

	public void addTest1ClassEventListener(ITest1ClassEventListener listener) {
	}
	public void removeTest1ClassEventListener(ITest1ClassEventListener listener) {
	}

	public void addTest1ClassUnicastEventListener(ITest1ClassUnicastEventListener listener) throws TooManyListenersException {
	}
	public void removeTest1ClassUnicastEventListener(ITest1ClassUnicastEventListener listener) {
	}
}