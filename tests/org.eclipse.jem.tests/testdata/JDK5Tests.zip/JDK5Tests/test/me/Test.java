package test.me;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import test.dependents.IBar;
import test.dependents.IFoo;
import test.dependents.Tester;

public class Test <Y extends Serializable> {
	
	public Collection<String> test1() {
		return null;
	}
	
	public void test2(Collection<? extends IFoo> aCollection) {
		
	}
	
	public <T extends IFoo> T test3(Class<T> aClass, String s, List<Integer> aList) {
		return null;
	}
	
	public Map<Integer, String> test4(Integer anInteger) {
		return null;
	}
	
	public void test5(List<? super IFoo> aList) {
	}
	
	public <T> void test6(Class<T>[] aClassArray, List<String>[] anArrayOfListsOfString, Class<?>[] aWildcardClassArray, Class<?>[][][] aMultiDimWildcardArray) {
	}
	
	public <T> void test7(List<List<String>> aListOfListOfString, List<List<T>> aListOfListOfT, Map<IFoo, List<Map<IBar, T>>> aMap) {
	}
	
	public void test8(List<? extends List<String>> aList) {	
	}
	
	public <T> void test9(java.util.List<java.util.List<java.lang.String>> aListOfListOfString, java.util.List<java.util.List<T>> aListOfListOfT, java.util.Map<test.dependents.IFoo, java.util.List<java.util.Map<test.dependents.IBar, T>>> aMap) {
	}
	
	public <T extends Tester> T test10(List<Integer> list) {
		return null;
	}
	
	public <T extends Tester> T[] test11() {
		return null;
	}
	
	public <T extends Tester> T[][][] test12() {
		return null;
	}

	public void test13(Y param) {
	}
}
