package test.dependents;

public interface IFoo {

}
