package test.dependents;

public interface IBar {

}
