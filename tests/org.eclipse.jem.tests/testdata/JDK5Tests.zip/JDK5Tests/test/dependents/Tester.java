package test.dependents;

public class Tester {

}
