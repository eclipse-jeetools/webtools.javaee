
public class test {
	
	public void foo(){
		System.out.println("FOO");
	}

}
