package testme;

public class Wow {

	public static String bar() {
		System.out.println("Bar was called!!!");
		return "Bar";
	}
}
