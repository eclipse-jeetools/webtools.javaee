package com.ibm.wtp.logger.proxyrender;
/*
 * Licensed Material - Property of IBM 
 * (C) Copyright IBM Corp. 2001, 2002 - All Rights Reserved. 
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp. 
 */

import com.ibm.wtp.common.logger.proxy.Logger;
/**
 * Insert the type's description here.
 * Creation date: (10/11/2001 9:14:22 AM)
 * @author: Administrator
 */
public interface IMsgLogger {
	public Logger getMsgLogger();
}
