package com.ibm.wtp.common;
/*
 * Licensed Material - Property of IBM 
 * (C) Copyright IBM Corp. 2001, 2002 - All Rights Reserved. 
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp. 
 */

/**
 * @author mdelder
 *
 * 
 */
public interface UITester {

	public boolean isCurrentContextUI();
}
