package com.ibm.wtp.emf.workbench;
/*
 * Licensed Material - Property of IBM 
 * (C) Copyright IBM Corp. 2001, 2002 - All Rights Reserved. 
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp. 
 */


public interface IEMFContextContributor {
	/**
	 * This is your opportunity to add a primary EMFNature.
	 * Typically you would add to the WorkbenchContext
	 * held by <code>aNature</code> in order to change
	 * the container for the WorkbenchURIConverter or add
	 * adapter factories to the ResourceSet or anything else that
	 * is needed.
	 */
	void primaryContributeToContext(EMFWorkbenchContextBase aNature);
	
	/**
	 * This is your opportunity to add a secondary EMFNature.
	 * Typically you would add to the WorkbenchContext
	 * held by <code>aNature</code> in order to change
	 * the container for the WorkbenchURIConverter or add
	 * adapter factories to the ResourceSet or anything else that
	 * is needed.
	 */
	void secondaryContributeToContext(EMFWorkbenchContextBase aNature);

}
