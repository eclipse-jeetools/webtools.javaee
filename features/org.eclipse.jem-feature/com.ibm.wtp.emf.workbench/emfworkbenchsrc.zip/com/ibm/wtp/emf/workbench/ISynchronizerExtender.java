package com.ibm.wtp.emf.workbench;

import org.eclipse.core.resources.IResourceDelta;

/*
 * Licensed Material - Property of IBM 
 * (C) Copyright IBM Corp. 2001, 2002 - All Rights Reserved. 
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp. 
 */



/**
 * allows clients, eg {@link com.ibm.wtp.emf.workbench.EMFNatureContributor}, to
 * extend the behavior of the ResourceSetWorkbenchSynchronizer
 */
public interface ISynchronizerExtender {
	
	void projectChanged(IResourceDelta delta);

	void projectClosed();
}
